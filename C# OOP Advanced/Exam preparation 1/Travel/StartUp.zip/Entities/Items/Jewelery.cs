﻿namespace Travel.Entities.Items
{
	public class Jewelery : Item
	{
		public Jewelery()
			: base(value: 300)
		{
		}
	}
}