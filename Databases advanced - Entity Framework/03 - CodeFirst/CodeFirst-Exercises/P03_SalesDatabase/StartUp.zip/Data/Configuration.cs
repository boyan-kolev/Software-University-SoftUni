﻿namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-PHQG6TO\\SQLEXPRESS; Database=Sales; Integrated Security=true;";
    }
}
