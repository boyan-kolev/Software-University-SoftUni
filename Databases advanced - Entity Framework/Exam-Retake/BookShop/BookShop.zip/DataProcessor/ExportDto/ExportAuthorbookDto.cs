﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ExportDto
{
    public class ExportAuthorbookDto
    {
        public string BookName { get; set; }
        public string BookPrice { get; set; }
    }
}
