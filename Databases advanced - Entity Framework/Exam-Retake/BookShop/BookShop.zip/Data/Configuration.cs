﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-PHQG6TO\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}