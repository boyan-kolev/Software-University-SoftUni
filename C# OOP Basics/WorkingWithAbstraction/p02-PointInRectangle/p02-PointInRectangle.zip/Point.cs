﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PointInRectangle
{
    class Point
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
