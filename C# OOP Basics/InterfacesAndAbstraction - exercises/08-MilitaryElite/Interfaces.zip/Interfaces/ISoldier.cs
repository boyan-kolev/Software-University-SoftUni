﻿namespace Problem_8.Military_Elite.Interfaces
{
    public interface ISoldier
    {
        int Id { get; }

        string FirstName { get; }

        string LastName { get; }
    }
}