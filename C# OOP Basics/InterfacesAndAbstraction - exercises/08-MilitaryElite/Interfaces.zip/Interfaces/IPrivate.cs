﻿namespace Problem_8.Military_Elite.Interfaces
{
    public interface IPrivate
    {
        double Salary { get; }
    }
}