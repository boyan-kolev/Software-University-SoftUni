﻿namespace Problem_8.Military_Elite.Interfaces
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}