﻿namespace BirthdayCelebrations.Core
{
    internal class list<T>
    {
    }
}